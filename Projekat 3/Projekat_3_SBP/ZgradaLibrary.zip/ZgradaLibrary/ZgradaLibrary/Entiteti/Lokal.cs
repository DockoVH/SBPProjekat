﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZgradaLibrary.Entiteti;

internal class Lokal : Prostor
{
    public virtual string? ImeFirme { get; set; }

    public Lokal()
    {
        
    }
}
