﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZgradaLibrary.Entiteti;

internal class LiftZaLjude : Lift
{
    public virtual int KapLjudi { get; set; }

    public LiftZaLjude()
    {
        
    }
}
