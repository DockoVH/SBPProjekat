﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZgradaLibrary.Entiteti;

internal class LiftTeretni : Lift
{
    public virtual double Nosivost { get; set; }

    public LiftTeretni()
    {
        
    }
}
