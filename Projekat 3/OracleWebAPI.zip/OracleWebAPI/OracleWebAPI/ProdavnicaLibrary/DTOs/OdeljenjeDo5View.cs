﻿namespace ProdavnicaLibrary.DTOs;

public class OdeljenjeDo5View : OdeljenjeView
{
    public OdeljenjeDo5View()
    {
    }

    internal OdeljenjeDo5View(Odeljenje? o) : base(o)
    {
    }

    internal OdeljenjeDo5View(Odeljenje? o, Prodavnica? p) : base(o, p)
    {
    }
}
