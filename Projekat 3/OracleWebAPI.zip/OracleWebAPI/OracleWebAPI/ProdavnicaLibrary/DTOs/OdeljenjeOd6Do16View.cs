﻿namespace ProdavnicaLibrary.DTOs;

public class OdeljenjeOd6Do16View : OdeljenjeView
{
    public OdeljenjeOd6Do16View()
    {
    }

    internal OdeljenjeOd6Do16View(Odeljenje? o) : base(o)
    {
    }

    internal OdeljenjeOd6Do16View(Odeljenje? o, Prodavnica? p) : base(o, p)
    {
    }
}
