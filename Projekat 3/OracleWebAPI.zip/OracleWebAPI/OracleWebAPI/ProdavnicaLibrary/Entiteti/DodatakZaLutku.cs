﻿namespace ProdavnicaLibrary.Entiteti;

internal class DodatakZaLutku : Proizvod
{
    internal protected virtual string? NazivDodatka { get; set; }
    internal protected virtual string? TipDodatka { get; set; }
}
