﻿namespace ProdavnicaLibrary.Entiteti;

internal class Lutka : Proizvod
{
    internal protected virtual string? Ime { get; set; }
    internal protected virtual string? Govori { get; set; }
    internal protected virtual string? OsetljivaDodir { get; set; }
}
