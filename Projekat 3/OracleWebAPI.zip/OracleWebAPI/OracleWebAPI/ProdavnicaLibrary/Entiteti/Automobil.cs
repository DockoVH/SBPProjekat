﻿namespace ProdavnicaLibrary.Entiteti;

internal class Automobil : Proizvod
{
    internal protected virtual string? NazivSerije { get; set; }
    internal protected virtual string? Baterije { get; set; }
}
