﻿namespace Prodavnica
{
    partial class DodajProizvodOd6Do15Forma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbDodaciZaLutke = new System.Windows.Forms.RadioButton();
            this.rdbLutke = new System.Windows.Forms.RadioButton();
            this.rdbIgrackePlastika = new System.Windows.Forms.RadioButton();
            this.rdbPuzzle = new System.Windows.Forms.RadioButton();
            this.rdbVojnici = new System.Windows.Forms.RadioButton();
            this.rdbAutomobili = new System.Windows.Forms.RadioButton();
            this.btnOdaberi = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbDodaciZaLutke);
            this.groupBox1.Controls.Add(this.rdbLutke);
            this.groupBox1.Controls.Add(this.rdbIgrackePlastika);
            this.groupBox1.Controls.Add(this.rdbPuzzle);
            this.groupBox1.Controls.Add(this.rdbVojnici);
            this.groupBox1.Controls.Add(this.rdbAutomobili);
            this.groupBox1.Controls.Add(this.btnOdaberi);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(224, 329);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Odaberite tip igracke";
            // 
            // rdbDodaciZaLutke
            // 
            this.rdbDodaciZaLutke.AutoSize = true;
            this.rdbDodaciZaLutke.Location = new System.Drawing.Point(7, 206);
            this.rdbDodaciZaLutke.Name = "rdbDodaciZaLutke";
            this.rdbDodaciZaLutke.Size = new System.Drawing.Size(197, 28);
            this.rdbDodaciZaLutke.TabIndex = 5;
            this.rdbDodaciZaLutke.TabStop = true;
            this.rdbDodaciZaLutke.Text = "DODACI ZA LUTKE";
            this.rdbDodaciZaLutke.UseVisualStyleBackColor = true;
            // 
            // rdbLutke
            // 
            this.rdbLutke.AutoSize = true;
            this.rdbLutke.Location = new System.Drawing.Point(7, 172);
            this.rdbLutke.Name = "rdbLutke";
            this.rdbLutke.Size = new System.Drawing.Size(91, 28);
            this.rdbLutke.TabIndex = 4;
            this.rdbLutke.TabStop = true;
            this.rdbLutke.Text = "LUTKE";
            this.rdbLutke.UseVisualStyleBackColor = true;
            // 
            // rdbIgrackePlastika
            // 
            this.rdbIgrackePlastika.AutoSize = true;
            this.rdbIgrackePlastika.Enabled = false;
            this.rdbIgrackePlastika.Location = new System.Drawing.Point(7, 139);
            this.rdbIgrackePlastika.Name = "rdbIgrackePlastika";
            this.rdbIgrackePlastika.Size = new System.Drawing.Size(206, 28);
            this.rdbIgrackePlastika.TabIndex = 3;
            this.rdbIgrackePlastika.TabStop = true;
            this.rdbIgrackePlastika.Text = "IGRACKE PLASTIKA";
            this.rdbIgrackePlastika.UseVisualStyleBackColor = true;
            // 
            // rdbPuzzle
            // 
            this.rdbPuzzle.AutoSize = true;
            this.rdbPuzzle.Enabled = false;
            this.rdbPuzzle.Location = new System.Drawing.Point(7, 107);
            this.rdbPuzzle.Name = "rdbPuzzle";
            this.rdbPuzzle.Size = new System.Drawing.Size(103, 28);
            this.rdbPuzzle.TabIndex = 2;
            this.rdbPuzzle.TabStop = true;
            this.rdbPuzzle.Text = "PUZZLE";
            this.rdbPuzzle.UseVisualStyleBackColor = true;
            // 
            // rdbVojnici
            // 
            this.rdbVojnici.AutoSize = true;
            this.rdbVojnici.Location = new System.Drawing.Point(7, 73);
            this.rdbVojnici.Name = "rdbVojnici";
            this.rdbVojnici.Size = new System.Drawing.Size(103, 28);
            this.rdbVojnici.TabIndex = 1;
            this.rdbVojnici.TabStop = true;
            this.rdbVojnici.Text = "VOJNICI";
            this.rdbVojnici.UseVisualStyleBackColor = true;
            // 
            // rdbAutomobili
            // 
            this.rdbAutomobili.AutoSize = true;
            this.rdbAutomobili.Location = new System.Drawing.Point(7, 39);
            this.rdbAutomobili.Name = "rdbAutomobili";
            this.rdbAutomobili.Size = new System.Drawing.Size(145, 28);
            this.rdbAutomobili.TabIndex = 0;
            this.rdbAutomobili.TabStop = true;
            this.rdbAutomobili.Text = "AUTOMOBILI";
            this.rdbAutomobili.UseVisualStyleBackColor = true;
            // 
            // btnOdaberi
            // 
            this.btnOdaberi.BackColor = System.Drawing.Color.SandyBrown;
            this.btnOdaberi.Font = new System.Drawing.Font("Georgia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnOdaberi.Location = new System.Drawing.Point(6, 268);
            this.btnOdaberi.Margin = new System.Windows.Forms.Padding(4);
            this.btnOdaberi.Name = "btnOdaberi";
            this.btnOdaberi.Size = new System.Drawing.Size(207, 53);
            this.btnOdaberi.TabIndex = 6;
            this.btnOdaberi.Text = "ODABERI";
            this.btnOdaberi.UseVisualStyleBackColor = false;
            this.btnOdaberi.Click += new System.EventHandler(this.btnOdaberi_Click);
            // 
            // DodajProizvodOd6Do15Forma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(242, 353);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(260, 400);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(260, 400);
            this.Name = "DodajProizvodOd6Do15Forma";
            this.Text = "DODAVANJE";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbDodaciZaLutke;
        private System.Windows.Forms.RadioButton rdbLutke;
        private System.Windows.Forms.RadioButton rdbIgrackePlastika;
        private System.Windows.Forms.RadioButton rdbPuzzle;
        private System.Windows.Forms.RadioButton rdbVojnici;
        private System.Windows.Forms.RadioButton rdbAutomobili;
        private System.Windows.Forms.Button btnOdaberi;
    }
}