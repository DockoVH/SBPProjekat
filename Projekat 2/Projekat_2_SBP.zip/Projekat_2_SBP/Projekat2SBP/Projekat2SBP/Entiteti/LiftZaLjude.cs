﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat2SBP.Entiteti;

public class LiftZaLjude : Lift
{
    public virtual int KapLjudi { get; set; }

    public LiftZaLjude()
    {
        
    }
}
