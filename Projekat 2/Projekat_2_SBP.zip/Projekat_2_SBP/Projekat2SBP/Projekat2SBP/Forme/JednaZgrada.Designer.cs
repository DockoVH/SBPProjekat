﻿namespace Projekat2SBP.Forme
{
    partial class JednaZgrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AdresaLabel = new Label();
            UpravnikLabel = new Label();
            BrojUgovoraLabel = new Label();
            BrojUlazaLabel = new Label();
            BrojLiftovaLabel = new Label();
            BrojSpratovaLabel = new Label();
            BrojStanovaLabel = new Label();
            BrojLokalaLabel = new Label();
            BrojParkingaLabel = new Label();
            BrojVlasnikaLabel = new Label();
            AdresaTextBox = new TextBox();
            UpravnikTextBox = new TextBox();
            BrojUgovoraTextBox = new TextBox();
            BrojUlazaTextBox = new TextBox();
            BrojLiftovaTextBox = new TextBox();
            BrojSpratovaTextBox = new TextBox();
            BrojStanovaTextBox = new TextBox();
            BrojLokalaTextBox = new TextBox();
            BrojParkingaTextBox = new TextBox();
            BrojVlasnikaTextBox = new TextBox();
            PrikaziUpravnikaDugme = new Button();
            SuspendLayout();
            // 
            // AdresaLabel
            // 
            AdresaLabel.AutoSize = true;
            AdresaLabel.Location = new Point(48, 34);
            AdresaLabel.Name = "AdresaLabel";
            AdresaLabel.Size = new Size(58, 20);
            AdresaLabel.TabIndex = 0;
            AdresaLabel.Text = "Adresa:";
            // 
            // UpravnikLabel
            // 
            UpravnikLabel.AutoSize = true;
            UpravnikLabel.Location = new Point(48, 67);
            UpravnikLabel.Name = "UpravnikLabel";
            UpravnikLabel.Size = new Size(70, 20);
            UpravnikLabel.TabIndex = 1;
            UpravnikLabel.Text = "Upravnik:";
            // 
            // BrojUgovoraLabel
            // 
            BrojUgovoraLabel.AutoSize = true;
            BrojUgovoraLabel.Location = new Point(48, 100);
            BrojUgovoraLabel.Name = "BrojUgovoraLabel";
            BrojUgovoraLabel.Size = new Size(98, 20);
            BrojUgovoraLabel.TabIndex = 2;
            BrojUgovoraLabel.Text = "Broj ugovora:";
            // 
            // BrojUlazaLabel
            // 
            BrojUlazaLabel.AutoSize = true;
            BrojUlazaLabel.Location = new Point(48, 133);
            BrojUlazaLabel.Name = "BrojUlazaLabel";
            BrojUlazaLabel.Size = new Size(78, 20);
            BrojUlazaLabel.TabIndex = 3;
            BrojUlazaLabel.Text = "Broj ulaza:";
            // 
            // BrojLiftovaLabel
            // 
            BrojLiftovaLabel.AutoSize = true;
            BrojLiftovaLabel.Location = new Point(48, 166);
            BrojLiftovaLabel.Name = "BrojLiftovaLabel";
            BrojLiftovaLabel.Size = new Size(85, 20);
            BrojLiftovaLabel.TabIndex = 4;
            BrojLiftovaLabel.Text = "Broj liftova:";
            // 
            // BrojSpratovaLabel
            // 
            BrojSpratovaLabel.AutoSize = true;
            BrojSpratovaLabel.Location = new Point(48, 199);
            BrojSpratovaLabel.Name = "BrojSpratovaLabel";
            BrojSpratovaLabel.Size = new Size(100, 20);
            BrojSpratovaLabel.TabIndex = 5;
            BrojSpratovaLabel.Text = "Broj spratova:";
            // 
            // BrojStanovaLabel
            // 
            BrojStanovaLabel.AutoSize = true;
            BrojStanovaLabel.Location = new Point(48, 232);
            BrojStanovaLabel.Name = "BrojStanovaLabel";
            BrojStanovaLabel.Size = new Size(94, 20);
            BrojStanovaLabel.TabIndex = 6;
            BrojStanovaLabel.Text = "Broj stanova:";
            // 
            // BrojLokalaLabel
            // 
            BrojLokalaLabel.AutoSize = true;
            BrojLokalaLabel.Location = new Point(48, 265);
            BrojLokalaLabel.Name = "BrojLokalaLabel";
            BrojLokalaLabel.Size = new Size(83, 20);
            BrojLokalaLabel.TabIndex = 7;
            BrojLokalaLabel.Text = "Broj lokala:";
            // 
            // BrojParkingaLabel
            // 
            BrojParkingaLabel.AutoSize = true;
            BrojParkingaLabel.Location = new Point(48, 298);
            BrojParkingaLabel.Name = "BrojParkingaLabel";
            BrojParkingaLabel.Size = new Size(137, 20);
            BrojParkingaLabel.TabIndex = 8;
            BrojParkingaLabel.Text = "Broj parking mesta:";
            // 
            // BrojVlasnikaLabel
            // 
            BrojVlasnikaLabel.AutoSize = true;
            BrojVlasnikaLabel.Location = new Point(48, 331);
            BrojVlasnikaLabel.Name = "BrojVlasnikaLabel";
            BrojVlasnikaLabel.Size = new Size(150, 20);
            BrojVlasnikaLabel.TabIndex = 9;
            BrojVlasnikaLabel.Text = "Broj vlasnika stanova:";
            // 
            // AdresaTextBox
            // 
            AdresaTextBox.Location = new Point(179, 27);
            AdresaTextBox.Name = "AdresaTextBox";
            AdresaTextBox.Size = new Size(152, 27);
            AdresaTextBox.TabIndex = 10;
            // 
            // UpravnikTextBox
            // 
            UpravnikTextBox.Location = new Point(179, 60);
            UpravnikTextBox.Name = "UpravnikTextBox";
            UpravnikTextBox.Size = new Size(152, 27);
            UpravnikTextBox.TabIndex = 11;
            // 
            // BrojUgovoraTextBox
            // 
            BrojUgovoraTextBox.Location = new Point(292, 93);
            BrojUgovoraTextBox.Name = "BrojUgovoraTextBox";
            BrojUgovoraTextBox.Size = new Size(39, 27);
            BrojUgovoraTextBox.TabIndex = 12;
            // 
            // BrojUlazaTextBox
            // 
            BrojUlazaTextBox.Location = new Point(292, 126);
            BrojUlazaTextBox.Name = "BrojUlazaTextBox";
            BrojUlazaTextBox.Size = new Size(39, 27);
            BrojUlazaTextBox.TabIndex = 13;
            // 
            // BrojLiftovaTextBox
            // 
            BrojLiftovaTextBox.Location = new Point(292, 159);
            BrojLiftovaTextBox.Name = "BrojLiftovaTextBox";
            BrojLiftovaTextBox.Size = new Size(39, 27);
            BrojLiftovaTextBox.TabIndex = 14;
            // 
            // BrojSpratovaTextBox
            // 
            BrojSpratovaTextBox.Location = new Point(292, 192);
            BrojSpratovaTextBox.Name = "BrojSpratovaTextBox";
            BrojSpratovaTextBox.Size = new Size(39, 27);
            BrojSpratovaTextBox.TabIndex = 15;
            // 
            // BrojStanovaTextBox
            // 
            BrojStanovaTextBox.Location = new Point(292, 225);
            BrojStanovaTextBox.Name = "BrojStanovaTextBox";
            BrojStanovaTextBox.Size = new Size(39, 27);
            BrojStanovaTextBox.TabIndex = 16;
            // 
            // BrojLokalaTextBox
            // 
            BrojLokalaTextBox.Location = new Point(292, 258);
            BrojLokalaTextBox.Name = "BrojLokalaTextBox";
            BrojLokalaTextBox.Size = new Size(39, 27);
            BrojLokalaTextBox.TabIndex = 17;
            // 
            // BrojParkingaTextBox
            // 
            BrojParkingaTextBox.Location = new Point(292, 291);
            BrojParkingaTextBox.Name = "BrojParkingaTextBox";
            BrojParkingaTextBox.Size = new Size(39, 27);
            BrojParkingaTextBox.TabIndex = 18;
            // 
            // BrojVlasnikaTextBox
            // 
            BrojVlasnikaTextBox.Location = new Point(292, 324);
            BrojVlasnikaTextBox.Name = "BrojVlasnikaTextBox";
            BrojVlasnikaTextBox.Size = new Size(39, 27);
            BrojVlasnikaTextBox.TabIndex = 19;
            // 
            // PrikaziUpravnikaDugme
            // 
            PrikaziUpravnikaDugme.Location = new Point(337, 60);
            PrikaziUpravnikaDugme.Name = "PrikaziUpravnikaDugme";
            PrikaziUpravnikaDugme.Size = new Size(73, 27);
            PrikaziUpravnikaDugme.TabIndex = 20;
            PrikaziUpravnikaDugme.Text = "Prikaži";
            PrikaziUpravnikaDugme.UseVisualStyleBackColor = true;
            PrikaziUpravnikaDugme.Click += PrikaziUpravnikaDugme_Click;
            // 
            // JednaZgrada
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(422, 366);
            Controls.Add(PrikaziUpravnikaDugme);
            Controls.Add(BrojVlasnikaTextBox);
            Controls.Add(BrojParkingaTextBox);
            Controls.Add(BrojLokalaTextBox);
            Controls.Add(BrojStanovaTextBox);
            Controls.Add(BrojSpratovaTextBox);
            Controls.Add(BrojLiftovaTextBox);
            Controls.Add(BrojUlazaTextBox);
            Controls.Add(BrojUgovoraTextBox);
            Controls.Add(UpravnikTextBox);
            Controls.Add(AdresaTextBox);
            Controls.Add(BrojVlasnikaLabel);
            Controls.Add(BrojParkingaLabel);
            Controls.Add(BrojLokalaLabel);
            Controls.Add(BrojStanovaLabel);
            Controls.Add(BrojSpratovaLabel);
            Controls.Add(BrojLiftovaLabel);
            Controls.Add(BrojUlazaLabel);
            Controls.Add(BrojUgovoraLabel);
            Controls.Add(UpravnikLabel);
            Controls.Add(AdresaLabel);
            Name = "JednaZgrada";
            Text = "JednaZgrada";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label AdresaLabel;
        private Label UpravnikLabel;
        private Label BrojUgovoraLabel;
        private Label BrojUlazaLabel;
        private Label BrojLiftovaLabel;
        private Label BrojSpratovaLabel;
        private Label BrojStanovaLabel;
        private Label BrojLokalaLabel;
        private Label BrojParkingaLabel;
        private Label BrojVlasnikaLabel;
        private TextBox AdresaTextBox;
        private TextBox UpravnikTextBox;
        private TextBox BrojUgovoraTextBox;
        private TextBox BrojUlazaTextBox;
        private TextBox BrojLiftovaTextBox;
        private TextBox BrojSpratovaTextBox;
        private TextBox BrojStanovaTextBox;
        private TextBox BrojLokalaTextBox;
        private TextBox BrojParkingaTextBox;
        private TextBox BrojVlasnikaTextBox;
        private Button PrikaziUpravnikaDugme;
    }
}