﻿namespace Projekat2SBP.Forme
{
    partial class NoviVlasnik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            JMBGLabel = new Label();
            AdresaLabel = new Label();
            ImeLabel = new Label();
            ImeRoditeljaLabel = new Label();
            PrezimeLabel = new Label();
            BrojeviTelefonaLabel = new Label();
            JMBGTextBox = new TextBox();
            AdresaTextBox = new TextBox();
            ImeTextBox = new TextBox();
            ImeRoditeljaTextBox = new TextBox();
            PrezimeTextBox = new TextBox();
            BrojeviTelefonaDugme = new Button();
            DodajDugme = new Button();
            OtkaziDugme = new Button();
            FunkcijaLabel = new Label();
            FunkcijaTextBox = new TextBox();
            SuspendLayout();
            // 
            // JMBGLabel
            // 
            JMBGLabel.AutoSize = true;
            JMBGLabel.Location = new Point(55, 29);
            JMBGLabel.Name = "JMBGLabel";
            JMBGLabel.Size = new Size(49, 20);
            JMBGLabel.TabIndex = 0;
            JMBGLabel.Text = "JMBG:";
            // 
            // AdresaLabel
            // 
            AdresaLabel.AutoSize = true;
            AdresaLabel.Location = new Point(55, 62);
            AdresaLabel.Name = "AdresaLabel";
            AdresaLabel.Size = new Size(58, 20);
            AdresaLabel.TabIndex = 1;
            AdresaLabel.Text = "Adresa:";
            // 
            // ImeLabel
            // 
            ImeLabel.AutoSize = true;
            ImeLabel.Location = new Point(55, 95);
            ImeLabel.Name = "ImeLabel";
            ImeLabel.Size = new Size(37, 20);
            ImeLabel.TabIndex = 2;
            ImeLabel.Text = "Ime:";
            // 
            // ImeRoditeljaLabel
            // 
            ImeRoditeljaLabel.AutoSize = true;
            ImeRoditeljaLabel.Location = new Point(55, 128);
            ImeRoditeljaLabel.Name = "ImeRoditeljaLabel";
            ImeRoditeljaLabel.Size = new Size(97, 20);
            ImeRoditeljaLabel.TabIndex = 3;
            ImeRoditeljaLabel.Text = "Ime roditelja:";
            // 
            // PrezimeLabel
            // 
            PrezimeLabel.AutoSize = true;
            PrezimeLabel.Location = new Point(55, 161);
            PrezimeLabel.Name = "PrezimeLabel";
            PrezimeLabel.Size = new Size(65, 20);
            PrezimeLabel.TabIndex = 4;
            PrezimeLabel.Text = "Prezime:";
            // 
            // BrojeviTelefonaLabel
            // 
            BrojeviTelefonaLabel.AutoSize = true;
            BrojeviTelefonaLabel.Location = new Point(55, 197);
            BrojeviTelefonaLabel.Name = "BrojeviTelefonaLabel";
            BrojeviTelefonaLabel.Size = new Size(117, 20);
            BrojeviTelefonaLabel.TabIndex = 5;
            BrojeviTelefonaLabel.Text = "Brojevi telefona:";
            // 
            // JMBGTextBox
            // 
            JMBGTextBox.Location = new Point(254, 22);
            JMBGTextBox.Name = "JMBGTextBox";
            JMBGTextBox.Size = new Size(125, 27);
            JMBGTextBox.TabIndex = 6;
            JMBGTextBox.KeyPress += JMBGTextBox_KeyPress;
            // 
            // AdresaTextBox
            // 
            AdresaTextBox.Location = new Point(254, 55);
            AdresaTextBox.Name = "AdresaTextBox";
            AdresaTextBox.Size = new Size(125, 27);
            AdresaTextBox.TabIndex = 7;
            AdresaTextBox.KeyPress += AdresaTextBox_KeyPress;
            // 
            // ImeTextBox
            // 
            ImeTextBox.Location = new Point(254, 88);
            ImeTextBox.Name = "ImeTextBox";
            ImeTextBox.Size = new Size(125, 27);
            ImeTextBox.TabIndex = 8;
            ImeTextBox.KeyPress += ImeTextBox_KeyPress;
            // 
            // ImeRoditeljaTextBox
            // 
            ImeRoditeljaTextBox.Location = new Point(254, 121);
            ImeRoditeljaTextBox.Name = "ImeRoditeljaTextBox";
            ImeRoditeljaTextBox.Size = new Size(125, 27);
            ImeRoditeljaTextBox.TabIndex = 9;
            ImeRoditeljaTextBox.KeyPress += ImeRoditeljaTextBox_KeyPress;
            // 
            // PrezimeTextBox
            // 
            PrezimeTextBox.Location = new Point(254, 155);
            PrezimeTextBox.Name = "PrezimeTextBox";
            PrezimeTextBox.Size = new Size(125, 27);
            PrezimeTextBox.TabIndex = 10;
            PrezimeTextBox.KeyPress += PrezimeTextBox_KeyPress;
            // 
            // BrojeviTelefonaDugme
            // 
            BrojeviTelefonaDugme.Location = new Point(254, 188);
            BrojeviTelefonaDugme.Name = "BrojeviTelefonaDugme";
            BrojeviTelefonaDugme.Size = new Size(125, 29);
            BrojeviTelefonaDugme.TabIndex = 11;
            BrojeviTelefonaDugme.Text = "Prikaži";
            BrojeviTelefonaDugme.UseVisualStyleBackColor = true;
            BrojeviTelefonaDugme.Click += BrojeviTelefonaDugme_Click;
            // 
            // DodajDugme
            // 
            DodajDugme.Location = new Point(55, 290);
            DodajDugme.Name = "DodajDugme";
            DodajDugme.Size = new Size(142, 42);
            DodajDugme.TabIndex = 12;
            DodajDugme.Text = "Dodaj";
            DodajDugme.UseVisualStyleBackColor = true;
            DodajDugme.Click += DodajDugme_Click;
            // 
            // OtkaziDugme
            // 
            OtkaziDugme.Location = new Point(237, 290);
            OtkaziDugme.Name = "OtkaziDugme";
            OtkaziDugme.Size = new Size(142, 42);
            OtkaziDugme.TabIndex = 13;
            OtkaziDugme.Text = "Otkaži";
            OtkaziDugme.UseVisualStyleBackColor = true;
            OtkaziDugme.Click += OtkaziDugme_Click;
            // 
            // FunkcijaLabel
            // 
            FunkcijaLabel.AutoSize = true;
            FunkcijaLabel.Location = new Point(55, 230);
            FunkcijaLabel.Name = "FunkcijaLabel";
            FunkcijaLabel.Size = new Size(138, 20);
            FunkcijaLabel.TabIndex = 14;
            FunkcijaLabel.Text = "Funkcija u skupštini:";
            // 
            // FunkcijaTextBox
            // 
            FunkcijaTextBox.Location = new Point(254, 223);
            FunkcijaTextBox.Name = "FunkcijaTextBox";
            FunkcijaTextBox.Size = new Size(125, 27);
            FunkcijaTextBox.TabIndex = 15;
            FunkcijaTextBox.KeyPress += FunkcijaTextBox_KeyPress;
            // 
            // NoviVlasnik
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(427, 386);
            Controls.Add(FunkcijaTextBox);
            Controls.Add(FunkcijaLabel);
            Controls.Add(OtkaziDugme);
            Controls.Add(DodajDugme);
            Controls.Add(BrojeviTelefonaDugme);
            Controls.Add(PrezimeTextBox);
            Controls.Add(ImeRoditeljaTextBox);
            Controls.Add(ImeTextBox);
            Controls.Add(AdresaTextBox);
            Controls.Add(JMBGTextBox);
            Controls.Add(BrojeviTelefonaLabel);
            Controls.Add(PrezimeLabel);
            Controls.Add(ImeRoditeljaLabel);
            Controls.Add(ImeLabel);
            Controls.Add(AdresaLabel);
            Controls.Add(JMBGLabel);
            Name = "NoviVlasnik";
            Text = "NoviVlasnik";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label JMBGLabel;
        private Label AdresaLabel;
        private Label ImeLabel;
        private Label ImeRoditeljaLabel;
        private Label PrezimeLabel;
        private Label BrojeviTelefonaLabel;
        private TextBox JMBGTextBox;
        private TextBox AdresaTextBox;
        private TextBox ImeTextBox;
        private TextBox ImeRoditeljaTextBox;
        private TextBox PrezimeTextBox;
        private Button BrojeviTelefonaDugme;
        private Button DodajDugme;
        private Button OtkaziDugme;
        private Label FunkcijaLabel;
        private TextBox FunkcijaTextBox;
    }
}